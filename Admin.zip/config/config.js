const session_secret = "luciferlord0123456789";
const email = "luciferlordsa321@gmail.com";
const emailPassword = "ydjiubgveiksncfw";
const config = {
  secret_jwt: process.env.SECERT_JWT_TOKEN,
};
module.exports = {
  session_secret,
  emailPassword,
  email,
  config,
};
