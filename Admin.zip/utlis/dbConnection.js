const mongoose = require("mongoose");

var mongooseUrl = process.env.DB_URL;
mongoose.connect(mongooseUrl);
var dbconnect = mongoose.connection;
dbconnect.on("error", () => {
  console.log("database Connection failed");
});
dbconnect.on("connected", () => {
  console.log("database Connection successfully");
});
module.exports = mongoose;
